# details of the data
dated : 05-08-2017
#===========================================
# details of user
#===========================================
 name : sher azam
 arm: right


the data is recorded on 5 agust. 140 reading are taken for each gesture.
readings for the gestures "fist" and "finger sepread" are recorded at  2:00am 5 agust.
after recording the data for first two gestures position of sensor is marked and 
readings for the gestures "wave out" and "wave in" are recorded at 1:30pm 5 Agust
